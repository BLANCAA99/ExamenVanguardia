<script setup>
</script>

<template>
  <div id="app" class="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
    <!-- Header -->
    <header class="bg-gradient-to-r from-blue-600 to-indigo-700 text-white shadow-lg">
      <div class="container mx-auto px-4 py-6">
        <div class="text-center">
          <h1 class="text-4xl font-bold mb-2">
            Aseguradora VitalCare
          </h1>
          <p class="text-blue-100 text-lg">
            Sistema de Gestión de Pólizas de Seguro
          </p>
        </div>
      </div>
    </header>

    <!-- Main Content - Updated Layout -->
    <main class="container mx-auto px-4 py-8">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        <!-- Left Column - Formulario de Póliza -->
        <div class="lg:col-span-1">
          <div class="bg-white rounded-xl shadow-lg p-8 border border-gray-200 sticky top-8">
            <div class="flex items-center justify-between mb-6">
              <h2 class="text-2xl font-bold text-gray-800">
                {{ modoEdicion ? 'Editar Póliza' : 'Nueva Póliza' }}
              </h2>
              <div class="text-sm text-gray-500">
                Total: {{ polizas.length }}
              </div>
            </div>
            
            <form @submit.prevent="enviarFormulario" class="space-y-6">
              <!-- Número de Póliza -->
              <div class="space-y-2">
                <label class="block text-sm font-semibold text-gray-700">
                  Número de Póliza
                </label>
                <input
                  v-model="formulario.numeroPoliza"
                  type="text"
                  required
                  :disabled="modoEdicion"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 disabled:bg-gray-100"
                  placeholder="Ej: POL-2025-001"
                />
              </div>

              <!-- Tipo de Seguro -->
              <div class="space-y-2">
                <label class="block text-sm font-semibold text-gray-700">
                  Tipo de Seguro
                </label>
                <select
                  v-model="formulario.tipoSeguro"
                  required
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                >
                  <option value="">Seleccionar tipo</option>
                  <option value="Auto">Auto</option>
                  <option value="Vida">Vida</option>
                  <option value="Hogar">Hogar</option>
                  <option value="Salud">Salud</option>
                </select>
              </div>

              <!-- Titular -->
              <div class="space-y-2">
                <label class="block text-sm font-semibold text-gray-700">
                  Titular de la Póliza
                </label>
                <input
                  v-model="formulario.titular"
                  type="text"
                  required
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                  placeholder="Nombre completo del titular"
                />
              </div>

              <!-- Monto -->
              <div class="space-y-2">
                <label class="block text-sm font-semibold text-gray-700">
                  Monto Asegurado
                </label>
                <div class="relative">
                  <span class="absolute left-3 top-3 text-gray-500">$</span>
                  <input
                    v-model="formulario.monto"
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    class="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    placeholder="0.00"
                  />
                </div>
              </div>

              <!-- Botones -->
              <div class="space-y-4 pt-4">
                <button
                  type="submit"
                  :disabled="cargandoFormulario"
                  class="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center"
                >
                  <span v-if="cargandoFormulario" class="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></span>
                  {{ cargandoFormulario ? 'Procesando...' : (modoEdicion ? 'Actualizar Póliza' : 'Crear Póliza') }}
                </button>
                
                <button
                  v-if="modoEdicion"
                  type="button"
                  @click="cancelarEdicion"
                  class="w-full bg-gray-500 text-white font-semibold py-3 px-6 rounded-lg hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>

        <!-- Right Column - Lista de Pólizas -->
        <div class="lg:col-span-1">
          <div class="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
            <div class="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
              <h2 class="text-2xl font-bold text-gray-800">Pólizas Registradas</h2>
              <button
                @click="cargarPolizas"
                :disabled="cargandoLista"
                class="bg-green-600 text-white font-semibold px-6 py-2 rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50 transition-all duration-200 flex items-center"
              >
                <span v-if="cargandoLista" class="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></span>
                {{ cargandoLista ? 'Cargando...' : 'Actualizar Lista' }}
              </button>
            </div>

            <!-- Estado de carga -->
            <div v-if="cargandoLista && polizas.length === 0" class="text-center py-12">
              <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p class="text-gray-600 text-lg">Cargando pólizas...</p>
            </div>

            <!-- Sin pólizas -->
            <div v-else-if="polizas.length === 0" class="text-center py-12">
              <div class="text-6xl mb-4">📄</div>
              <p class="text-gray-600 text-lg mb-2">No hay pólizas registradas</p>
              <p class="text-gray-500">Crea tu primera póliza usando el formulario</p>
            </div>

            <!-- Lista de pólizas (versión vertical para columna derecha) -->
            <div v-else class="space-y-4 max-h-96 overflow-y-auto">
              <transition-group name="slide-up" tag="div">
                <div
                  v-for="poliza in polizas"
                  :key="poliza._id"
                  class="bg-gradient-to-br from-gray-50 to-white border border-gray-200 rounded-xl p-4 hover:shadow-lg transition-all duration-300"
                >
                  <!-- Header de la tarjeta -->
                  <div class="flex justify-between items-start mb-3">
                    <div>
                      <h3 class="text-base font-bold text-gray-800 mb-1">
                        {{ poliza.numeroPoliza }}
                      </h3>
                      <span
                        class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium"
                        :class="obtenerColorTipo(poliza.tipoSeguro)"
                      >
                        {{ poliza.tipoSeguro }}
                      </span>
                    </div>
                    <div class="text-right">
                      <div class="text-lg font-bold text-green-600">
                        ${{ Number(poliza.monto).toLocaleString() }}
                      </div>
                    </div>
                  </div>
                  
                  <!-- Información de la póliza -->
                  <div class="space-y-2 mb-4">
                    <div class="flex items-center text-gray-600 text-sm">
                      <span class="font-medium mr-2">Titular:</span>
                      <span class="truncate">{{ poliza.titular }}</span>
                    </div>
                    <div class="flex items-center text-gray-600 text-sm">
                      <span class="font-medium mr-2">Creada:</span>
                      <span>{{ formatearFecha(poliza.createdAt) }}</span>
                    </div>
                  </div>
                  
                  <!-- Botones de acción -->
                  <div class="flex gap-2">
                    <button
                      @click="editarPoliza(poliza)"
                      class="flex-1 bg-yellow-500 text-white font-medium py-2 px-3 rounded-lg hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:ring-offset-2 transition-all duration-200 flex items-center justify-center text-sm"
                    >
                      Editar
                    </button>
                    <button
                      @click="eliminarPoliza(poliza._id, poliza.numeroPoliza)"
                      class="flex-1 bg-red-500 text-white font-medium py-2 px-3 rounded-lg hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-all duration-200 flex items-center justify-center text-sm"
                    >
                      Eliminar
                    </button>
                  </div>
                </div>
              </transition-group>
            </div>
          </div>
        </div>

      </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white text-center py-6 mt-12">
      <div class="container mx-auto px-4">
        <p class="text-lg font-medium">&copy; 2025 Aseguradora VitalCare</p>
        <p class="text-gray-400 mt-1">Sistema de Gestión de Pólizas - Todos los derechos reservados</p>
      </div>
    </footer>

    <!-- Notificaciones Toast -->
    <transition name="fade">
      <div
        v-if="notificacion.mostrar"
        :class="[
          'fixed top-4 right-4 px-6 py-4 rounded-lg shadow-xl z-50 max-w-sm',
          notificacion.tipo === 'success' ? 'bg-green-500 text-white' : 
          notificacion.tipo === 'error' ? 'bg-red-500 text-white' : 
          'bg-blue-500 text-white'
        ]"
      >
        <div class="flex items-center">
          <span class="text-2xl mr-3">
            {{ notificacion.tipo === 'success' ? '✅' : notificacion.tipo === 'error' ? '❌' : 'ℹ️' }}
          </span>
          <div>
            <p class="font-medium">{{ notificacion.titulo }}</p>
            <p class="text-sm opacity-90">{{ notificacion.mensaje }}</p>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
import { polizasService } from './services/polizasService.js';

export default {
  name: 'App',
  data() {
    return {
      // Lista de pólizas
      polizas: [],
      
      // Formulario
      formulario: {
        numeroPoliza: '',
        tipoSeguro: '',
        titular: '',
        monto: ''
      },
      
      // Estados
      modoEdicion: false,
      polizaEditandoId: null,
      cargandoFormulario: false,
      cargandoLista: false,
      
      // Notificaciones
      notificacion: {
        mostrar: false,
        tipo: 'info', // success, error, info
        titulo: '',
        mensaje: ''
      }
    };
  },
  
  mounted() {
    this.cargarPolizas();
  },
  
  methods: {
    // GET - Cargar todas las pólizas
    async cargarPolizas() {
      this.cargandoLista = true;
      try {
        this.polizas = await polizasService.obtenerTodasLasPolizas();
        if (this.polizas.length > 0) {
          this.mostrarNotificacion('success', 'Datos cargados', `Se cargaron ${this.polizas.length} pólizas exitosamente`);
        }
      } catch (error) {
        console.error('Error al cargar pólizas:', error);
        this.mostrarNotificacion('error', 'Error al cargar', error.message);
        this.polizas = [];
      } finally {
        this.cargandoLista = false;
      }
    },

    // POST/PUT - Enviar formulario (crear o actualizar)
    async enviarFormulario() {
      this.cargandoFormulario = true;
      try {
        if (this.modoEdicion) {
          // PUT - Actualizar póliza existente
          await polizasService.actualizarPoliza(this.polizaEditandoId, this.formulario);
          this.mostrarNotificacion('success', 'Póliza actualizada', `La póliza ${this.formulario.numeroPoliza} se actualizó correctamente`);
        } else {
          // POST - Crear nueva póliza
          await polizasService.crearPoliza(this.formulario);
          this.mostrarNotificacion('success', 'Póliza creada', `La póliza ${this.formulario.numeroPoliza} se creó exitosamente`);
        }
        
        this.limpiarFormulario();
        await this.cargarPolizas();
      } catch (error) {
        console.error('Error en formulario:', error);
        this.mostrarNotificacion('error', 'Error en formulario', error.message);
      } finally {
        this.cargandoFormulario = false;
      }
    },

    // Preparar formulario para edición
    editarPoliza(poliza) {
      this.formulario = {
        numeroPoliza: poliza.numeroPoliza,
        tipoSeguro: poliza.tipoSeguro,
        titular: poliza.titular,
        monto: poliza.monto
      };
      this.modoEdicion = true;
      this.polizaEditandoId = poliza._id;
      
      this.mostrarNotificacion('info', 'Modo edición', `Editando póliza ${poliza.numeroPoliza}`);
    },

    // Cancelar edición
    cancelarEdicion() {
      this.limpiarFormulario();
      this.mostrarNotificacion('info', 'Edición cancelada', 'Se canceló la edición de la póliza');
    },

    // DELETE - Eliminar póliza
    async eliminarPoliza(id, numeroPoliza) {
      const confirmacion = confirm(`¿Estás seguro de que quieres eliminar la póliza ${numeroPoliza}?\n\nEsta acción no se puede deshacer.`);
      if (!confirmacion) return;
      
      try {
        await polizasService.eliminarPoliza(id);
        this.mostrarNotificacion('success', 'Póliza eliminada', `La póliza ${numeroPoliza} se eliminó correctamente`);
        await this.cargarPolizas();
      } catch (error) {
        console.error('Error al eliminar póliza:', error);
        this.mostrarNotificacion('error', 'Error al eliminar', error.message);
      }
    },

    // Limpiar formulario
    limpiarFormulario() {
      this.formulario = {
        numeroPoliza: '',
        tipoSeguro: '',
        titular: '',
        monto: ''
      };
      this.modoEdicion = false;
      this.polizaEditandoId = null;
    },

    // Mostrar notificación
    mostrarNotificacion(tipo, titulo, mensaje) {
      this.notificacion = {
        mostrar: true,
        tipo,
        titulo,
        mensaje
      };
      
      setTimeout(() => {
        this.notificacion.mostrar = false;
      }, 4000);
    },

    // Obtener color según tipo de seguro
    obtenerColorTipo(tipo) {
      const colores = {
        'Auto': 'bg-blue-100 text-blue-800 border-blue-200',
        'Vida': 'bg-red-100 text-red-800 border-red-200',
        'Hogar': 'bg-green-100 text-green-800 border-green-200',
        'Salud': 'bg-purple-100 text-purple-800 border-purple-200'
      };
      return colores[tipo] || 'bg-gray-100 text-gray-800 border-gray-200';
    },

    // Formatear fecha
    formatearFecha(fechaString) {
      const fecha = new Date(fechaString);
      return fecha.toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    }
  }
};
</script>

<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

.slide-up-enter-active,
.slide-up-leave-active {
  transition: all 0.3s ease-out;
}

.slide-up-enter-from {
  opacity: 0;
  transform: translateY(30px);
}

.slide-up-leave-to {
  opacity: 0;
  transform: translateY(-30px);
}
</style>
