import axios from 'axios';

const API_BASE_URL = 'http://localhost:3000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10 segundos timeout
});

// Interceptor para logging de requests
api.interceptors.request.use((config) => {
  console.log(`🚀 ${config.method?.toUpperCase()} ${config.url}`, config.data);
  return config;
});

// Interceptor para manejo de errores
api.interceptors.response.use(
  (response) => {
    console.log(`✅ Respuesta recibida:`, response.data);
    return response;
  },
  (error) => {
    console.error('❌ Error en la API:', error);
    if (error.code === 'ECONNREFUSED') {
      console.error('🔌 No se puede conectar al servidor. ¿Está corriendo en puerto 3000?');
    }
    return Promise.reject(error);
  }
);

export const polizasService = {
  // Función de prueba de conexión
  probarConexion: async () => {
    try {
      const response = await api.get('/test');
      console.log('🎯 Conexión al servidor exitosa:', response.data);
      return true;
    } catch (error) {
      console.error('💥 Error de conexión:', error.message);
      throw new Error('No se puede conectar al servidor');
    }
  },

  // GET - Obtener todas las pólizas
  obtenerTodasLasPolizas: async () => {
    try {
      const response = await api.get('/polizas');
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.error || 'Error al obtener pólizas');
    }
  },

  // GET - Obtener una póliza por ID
  obtenerPolizaPorId: async (id) => {
    try {
      const response = await api.get(`/polizas/${id}`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.error || 'Error al obtener la póliza');
    }
  },

  // POST - Crear nueva póliza
  crearPoliza: async (polizaData) => {
    try {
      const response = await api.post('/polizas', polizaData);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.error || 'Error al crear la póliza');
    }
  },

  // PUT - Actualizar póliza existente
  actualizarPoliza: async (id, polizaData) => {
    try {
      const response = await api.put(`/polizas/${id}`, polizaData);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.error || 'Error al actualizar la póliza');
    }
  },

  // DELETE - Eliminar póliza
  eliminarPoliza: async (id) => {
    try {
      const response = await api.delete(`/polizas/${id}`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.error || 'Error al eliminar la póliza');
    }
  }
};