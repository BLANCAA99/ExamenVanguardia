# ExamenII-Vanguardia

Sistema de Gestión de Pólizas de Seguro - Aseguradora VitalCare

## Descripción

Aplicación web completa para la gestión de pólizas de seguros desarrollada con:
- **Frontend**: Vue.js 3 con estilos CSS personalizados
- **Backend**: Node.js con Express
- **Base de datos**: MongoDB Atlas

## Características

- ✅ Crear nuevas pólizas de seguro
- ✅ Listar todas las pólizas registradas
- ✅ Editar pólizas existentes
- ✅ Eliminar pólizas
- ✅ Validación de datos
- ✅ Interfaz responsive y moderna
- ✅ Notificaciones en tiempo real

## Tipos de Seguro Soportados

- 🚗 Auto
- ❤️ Vida
- 🏠 Hogar
- 🏥 Salud

## Instalación y Uso

### Prerequisitos

- Node.js (v14 o superior)
- MongoDB Atlas (cuenta configurada)
- Git

### Backend

```bash
cd server
npm install
npm run dev
```

### Frontend

```bash
cd client
npm install
npm run dev
```

## Configuración

1. Crear archivo `.env` en la carpeta `server` con:
