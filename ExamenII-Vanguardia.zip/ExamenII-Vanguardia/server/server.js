import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import cors from 'cors';
import polizasRoutes from './routes/polizas.js';

dotenv.config();
const app = express();

// Configuración CORS para permitir comunicación con el frontend
app.use(cors({
  origin: 'http://localhost:5173', // Puerto por defecto de Vite
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

// Middleware para logging de requests
app.use((req, res, next) => {
  console.log(`${req.method} ${req.path}`, req.body);
  next();
});

app.use('/api/polizas', polizasRoutes);

// Ruta de prueba
app.get('/api/test', (req, res) => {
  res.json({ mensaje: 'Servidor funcionando correctamente', timestamp: new Date() });
});

const PORT = process.env.PORT || 3000;

console.log('Intentando conectar a MongoDB...');
console.log('URI:', process.env.MONGODB_URI ? 'URI configurada' : 'URI no encontrada');

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('✅ Conectado a MongoDB Atlas exitosamente');
  console.log('Base de datos:', mongoose.connection.name);
  app.listen(PORT, () => {
    console.log(`🚀 Servidor escuchando en puerto ${PORT}`);
    console.log(`📡 API disponible en: http://localhost:${PORT}/api`);
  });
}).catch((error) => {
  console.error('❌ Error al conectar a MongoDB:', error);
  process.exit(1);
});

// Manejo de errores de MongoDB
mongoose.connection.on('error', (error) => {
  console.error('Error de MongoDB:', error);
});

mongoose.connection.on('disconnected', () => {
  console.log('MongoDB desconectado');
});